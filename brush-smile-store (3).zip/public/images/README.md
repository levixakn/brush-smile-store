วางรูปภาพสินค้าในโฟลเดอร์นี้ และแก้ค่า image ในชีต Products ให้ตรงกับ path เช่น /images/your-product.webp
