const SHEET_PRODUCTS = 'Products';
const SHEET_ORDERS = 'Orders';
const SHEET_ITEMS = 'OrderItems';

function setupSheets() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const products = getOrCreate_(ss, SHEET_PRODUCTS, ['sku','name','description','price','stock','image','active']);
  getOrCreate_(ss, SHEET_ORDERS, ['orderId','createdAt','name','phone','address','province','postcode','total','status','tracking']);
  getOrCreate_(ss, SHEET_ITEMS, ['orderId','sku','name','qty','price']);
  if (products.getLastRow() < 2) {
    products.getRange(2,1,2,7).setValues([
      ['BS-001','Daily Soft – แปรงขนนุ่ม','ขนแปรงนุ่มพิเศษ ปลายเรียว เข้าถึงซอกฟัน',89,45,'/images/brush-soft.svg',true],
      ['BS-002','Deep Clean – แปรงทำความสะอาดล้ำลึก','หัวแปรงกระชับ ขนแปรงหลายระดับ',119,32,'/images/brush-deep.svg',true]
    ]);
  }
  [products, ss.getSheetByName(SHEET_ORDERS), ss.getSheetByName(SHEET_ITEMS)].forEach(s => {
    s.setFrozenRows(1); s.getRange(1,1,1,s.getLastColumn()).setFontWeight('bold').setBackground('#e8f2eb');
  });
  return 'Sheets ready';
}
function getOrCreate_(ss, name, headers) {
  let sh = ss.getSheetByName(name);
  if (!sh) sh = ss.insertSheet(name);
  if (sh.getLastRow() === 0) sh.appendRow(headers);
  return sh;
}
function doGet() { return json_({ok:true,service:'BRUSH & SMILE API'}); }
function doPost(e) {
  const lock = LockService.getScriptLock();
  try {
    lock.waitLock(15000);
    const data = JSON.parse((e.postData && e.postData.contents) || '{}');
    const ss = SpreadsheetApp.getActiveSpreadsheet();
    const result = route_(ss, data);
    return json_(Object.assign({ok:true}, result || {}));
  } catch(err) {
    return json_({ok:false,error:String(err.message || err)});
  } finally {
    try { lock.releaseLock(); } catch (_) {}
  }
}
function route_(ss, d) {
  if (d.action === 'bootstrap') return {products:readObjects_(ss.getSheetByName(SHEET_PRODUCTS)),orders:readOrders_(ss)};
  if (d.action === 'createOrder') return createOrder_(ss,d);
  if (d.action === 'updateStatus') {
    const sh=ss.getSheetByName(SHEET_ORDERS), rows=sh.getDataRange().getValues();
    for(let i=1;i<rows.length;i++) if(String(rows[i][0])===String(d.orderId)){sh.getRange(i+1,9).setValue(d.status);return {};}
    throw new Error('ไม่พบคำสั่งซื้อ');
  }
  if (d.action === 'updateTracking') {
    const sh=ss.getSheetByName(SHEET_ORDERS), rows=sh.getDataRange().getValues();
    for(let i=1;i<rows.length;i++) if(String(rows[i][0])===String(d.orderId)){sh.getRange(i+1,10).setValue(String(d.tracking||''));return {};}
    throw new Error('ไม่พบคำสั่งซื้อ');
  }
  throw new Error('Unknown action');
}
function createOrder_(ss,d) {
  const c=d.customer||{}, items=d.items||[];
  ['name','phone','address','province','postcode'].forEach(k=>{if(!String(c[k]||'').trim())throw new Error('กรุณากรอกข้อมูลผู้รับให้ครบ');});
  if(!/^\d{5}$/.test(String(c.postcode))) throw new Error('รหัสไปรษณีย์ต้องมี 5 หลัก');
  if(!items.length) throw new Error('ไม่มีสินค้าในคำสั่งซื้อ');
  const ps=ss.getSheetByName(SHEET_PRODUCTS), values=ps.getDataRange().getValues(), bySku={};
  values.slice(1).forEach((r,i)=>bySku[String(r[0])]={row:i+2,name:r[1],price:Number(r[3]),stock:Number(r[4]),active:r[6]===true||String(r[6]).toLowerCase()==='true'});
  let total=0, normalized=[];
  items.forEach(it=>{
    const p=bySku[String(it.sku)], qty=Math.floor(Number(it.qty));
    if(!p||!p.active||qty<1) throw new Error('SKU ไม่ถูกต้อง: '+it.sku);
    if(qty>p.stock) throw new Error('สินค้า '+it.sku+' คงเหลือไม่พอ (เหลือ '+p.stock+')');
    total+=p.price*qty; normalized.push({sku:String(it.sku),name:p.name,qty,price:p.price,row:p.row});
  });
  normalized.forEach(it=>ps.getRange(it.row,5).setValue(bySku[it.sku].stock-it.qty));
  const id='BS'+Utilities.formatDate(new Date(),Session.getScriptTimeZone(),'yyMMddHHmmss')+Math.floor(Math.random()*900+100);
  ss.getSheetByName(SHEET_ORDERS).appendRow([id,new Date(),c.name,c.phone,c.address,c.province,c.postcode,total,'รอหยิบสินค้า','']);
  const is=ss.getSheetByName(SHEET_ITEMS);
  normalized.forEach(it=>is.appendRow([id,it.sku,it.name,it.qty,it.price]));
  return {orderId:id,total};
}
function readObjects_(sh) {
  if(!sh||sh.getLastRow()<2)return [];
  const vals=sh.getDataRange().getValues(), headers=vals.shift();
  return vals.map(r=>{const o={};headers.forEach((h,i)=>o[h]=r[i]);o.price=Number(o.price);o.stock=Number(o.stock);o.active=o.active===true||String(o.active).toLowerCase()==='true';return o;});
}
function readOrders_(ss) {
  const sh=ss.getSheetByName(SHEET_ORDERS), vals=sh.getDataRange().getValues();
  const its=ss.getSheetByName(SHEET_ITEMS).getDataRange().getValues(), grouped={};
  its.slice(1).forEach(r=>{(grouped[String(r[0])] ||= []).push({sku:r[1],name:r[2],qty:Number(r[3]),price:Number(r[4])});});
  return vals.slice(1).map(r=>({orderId:r[0],createdAt:r[1] instanceof Date?r[1].toISOString():r[1],name:r[2],phone:r[3],address:r[4],province:r[5],postcode:r[6],total:Number(r[7]),status:r[8],tracking:r[9],items:grouped[String(r[0])]||[]}));
}
function json_(obj) { return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON); }
