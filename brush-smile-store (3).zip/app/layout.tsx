import type { Metadata } from 'next';
import './globals.css';
export const metadata: Metadata = {
  title: 'BRUSH & SMILE | ดูแลรอยยิ้มทุกวัน',
  description: 'เลือกแปรงสีฟันที่เหมาะกับรอยยิ้มของคุณ พร้อมบริการจัดส่งถึงบ้าน'
};
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="th"><body>{children}</body></html>;
}
