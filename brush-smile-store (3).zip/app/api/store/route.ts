import { NextRequest, NextResponse } from 'next/server';
export const dynamic = 'force-dynamic';
export async function POST(req: NextRequest) {
  const endpoint = process.env.SHEETS_API_URL;
  if (!endpoint) return NextResponse.json({ok:false,error:'ยังไม่ได้ตั้งค่า SHEETS_API_URL ใน Vercel'}, {status:500});
  try {
    const payload = await req.json();
    const upstream = await fetch(endpoint, {
      method: 'POST',
      headers: {'Content-Type':'text/plain;charset=utf-8'},
      body: JSON.stringify(payload),
      cache: 'no-store'
    });
    const data = await upstream.json();
    return NextResponse.json(data, {status: upstream.ok ? 200 : upstream.status});
  } catch (error) {
    return NextResponse.json({ok:false,error:'เชื่อมต่อ Google Sheets ไม่สำเร็จ'}, {status:502});
  }
}
