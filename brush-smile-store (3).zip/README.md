# BRUSH & SMILE — ร้านค้าแปรงสีฟัน

โปรเจกต์ Next.js สำหรับ Landing Page + ตะกร้าสินค้า + Google Sheets order/inventory + หน้าหลังร้านสำหรับหยิบ/แพ็ก/พิมพ์ใบจ่าหน้า

## โครงสร้าง
- `app/` เว็บไซต์
- `public/images/` รูปสินค้าแยกจากโค้ด
- `google-apps-script/Code.gs` API เชื่อม Google Sheets
- `.env.example` ตัวแปรที่ต้องตั้งใน Vercel

## 1) เตรียม Google Sheets
1. สร้าง Google Spreadsheet ใหม่
2. เปิด Extensions → Apps Script
3. วางโค้ดจาก `google-apps-script/Code.gs`
4. กด Run ฟังก์ชัน `setupSheets` และอนุญาตสิทธิ์
5. Deploy → New deployment → Web app
6. Execute as: Me, Who has access: Anyone (หากต้องการให้หน้าร้านเรียก API ได้โดยตรง)
7. คัดลอก Web app URL ที่ลงท้าย `/exec`

ระบบจะสร้างชีต `Products`, `Orders`, `OrderItems` และใส่สินค้าเริ่มต้น 2 SKUs ให้โดยอัตโนมัติ

## 2) รันเว็บไซต์ในเครื่อง
```bash
npm install
cp .env.example .env.local
# ใส่ URL ของ Apps Script ใน SHEETS_API_URL
npm run dev
```
เปิด http://localhost:3000

## 3) ฝาก GitHub
สร้าง repository ใหม่ เช่น `brush-smile-store` แล้วอัปโหลดไฟล์ทั้งหมดในโฟลเดอร์นี้ (ไม่ต้องอัปโหลด `.env.local`)

## 4) Deploy Vercel
1. เข้า Vercel แล้วเลือก Add New → Project
2. Import Git Repository จาก GitHub
3. Framework: Next.js
4. เพิ่ม Environment Variable:
   - Name: `SHEETS_API_URL`
   - Value: URL จาก Apps Script
5. กด Deploy

## ขั้นตอนหลังร้าน
- เปิดส่วน “จัดการออเดอร์”
- ตรวจสอบข้อมูลผู้รับและรายการสินค้าแยกตาม SKU
- กด “เริ่มหยิบสินค้า” เมื่อเริ่ม Pick
- ตรวจนับและแพ็กสินค้า จากนั้นกด “ยืนยันแพ็กสินค้า”
- กรอกเลข Tracking แล้วบันทึก
- พิมพ์ใบจ่าหน้าพัสดุ และกด “ยืนยันจัดส่ง” เมื่อส่งมอบขนส่งแล้ว

## ข้อควรทราบก่อนใช้งานจริง
- สินค้าและราคาในหน้าเว็บเป็นข้อมูลตัวอย่าง ปรับได้ในชีต `Products`
- ควรจำกัดสิทธิ์หน้า Admin และเพิ่มระบบป้องกันสแปม/ตรวจสอบคำสั่งซื้อก่อนเปิดขายจริง โปรเจกต์ตัวอย่างนี้ยังไม่มีระบบล็อกอินหลังร้าน
- การพิมพ์ใบจ่าหน้าเป็นเอกสารข้อมูลผู้รับ ไม่ใช่ใบปะหน้าที่มีบาร์โค้ดจากผู้ให้บริการขนส่ง ต้องเชื่อม API ของขนส่งเพื่อสร้างฉลากมาตรฐาน
- การหักสต็อกจะเกิดเมื่อสร้างออเดอร์ และ Apps Script จะตรวจสอบสต็อกก่อนบันทึก
